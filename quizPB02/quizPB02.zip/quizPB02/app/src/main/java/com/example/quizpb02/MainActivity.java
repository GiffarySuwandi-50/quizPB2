package com.example.quizpb02;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    RadioGroup rgPSType, rgTambahan;
    EditText etJam;
    Button btnPesan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        rgPSType = findViewById(R.id.rgPSType); rgTambahan = findViewById(R.id.rgTambahan);
        etJam = findViewById(R.id.etJam);
        btnPesan = findViewById(R.id.btnPesan);


        btnPesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                totalPembayaran();
            }

            private void totalPembayaran() {
                int psTypePesanan = rgPSType.getCheckedRadioButtonId();
                int tambahanMakanan = rgTambahan.getCheckedRadioButtonId();
                String jamRental = etJam.getText().toString().trim();
                if (psTypePesanan == -1
                        || tambahanMakanan == -1
                        || jamRental.isEmpty()) {
                    Toast.makeText(MainActivity.this,
                            "Pilih PS, makanan, dan masukkan waktu",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                RadioButton tipePSDipilih = findViewById(psTypePesanan);
                RadioButton makananTambahanDipesan = findViewById(tambahanMakanan);
                int jamRentalPS = Integer.parseInt(jamRental);

                int rentalPS = hargaTiapPS(tipePSDipilih.getText().toString());
                int hargaMakanan = hargaTiapMakanan(makananTambahanDipesan.getText().toString());

                int totalBayar = (rentalPS * jamRentalPS)  + hargaMakanan;

                // Format Nominal
                NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
                String rentalPSDiformat = formatter.format(rentalPS);
                String hargaMakananDiformat = formatter.format(hargaMakanan);
                String totalBayarDiformat = formatter.format(totalBayar);

                Intent intent = new Intent(MainActivity.this, InvoiceActivity.class);
                intent.putExtra("Type", "Type: " + tipePSDipilih.getText().toString() + " (" + rentalPSDiformat + ")");
                intent.putExtra("Tambahan", makananTambahanDipesan.getText().toString() + ": " + hargaMakananDiformat);
                intent.putExtra("Jam", "Waktu: " + jamRentalPS + " Jam");
                intent.putExtra("Total", "Total: " + totalBayarDiformat);
                startActivity(intent);
            }
            private int hargaTiapPS(String psType) {
                switch (psType) {
                    case "PS5": return 10000;
                    case "PS4": return 8000;
                    case "PS3": return 5000;
                    case "PSVR": return 20000;
                    default: return 0;
                }
            }
            private int hargaTiapMakanan(String tambahan){
                switch (tambahan) {
                    case "Indomie": return 7000;
                    case "Mie Ayam": return 10000;
                    case "Siomay": return 5000;
                    default: return 0;
                }
            }
        });
    }
}