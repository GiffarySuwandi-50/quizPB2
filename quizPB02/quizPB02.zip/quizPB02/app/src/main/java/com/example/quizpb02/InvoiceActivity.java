package com.example.quizpb02;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class InvoiceActivity extends AppCompatActivity {
    TextView tvType, tvTambahan, tvWaktu, tvTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);

        tvType = findViewById(R.id.tvType);
        tvTambahan = findViewById(R.id.tvTambahan);
        tvWaktu = findViewById(R.id.tvWaktu);
        tvTotal = findViewById(R.id.tvTotal);

        Intent intent = getIntent();
        if (intent != null) {
            String tipePS = intent.getStringExtra("Type");
            String tambahanMakanan = intent.getStringExtra("Tambahan");
            String jamRental = intent.getStringExtra("Jam");
            String totalHarga = intent.getStringExtra("Total");

            tvType.setText(tipePS);
            tvTambahan.setText(tambahanMakanan);
            tvWaktu.setText(jamRental);
            tvTotal.setText(totalHarga);
        }
    }
}